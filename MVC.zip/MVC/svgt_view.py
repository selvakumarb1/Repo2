from PyQt6 import QtCore, QtGui,QtWidgets
from PyQt6.QtWidgets import QFileDialog, QMainWindow, QWidget, QLabel, QLineEdit,QComboBox,QPushButton
import sys


class SvgtView(QMainWindow):

	def __init__(self):	
		 QMainWindow.__init__(self)
		 vehicle_list=[]
		 self.vehicle_name=""
        # setting title
		 self.setWindowTitle("SVGT")  
        # setting geometry
		 self.setGeometry(500, 500, 700, 700)
        # calling method
		 self.create_ui()
        #showing all the widgets
		 self.show()
       
    # method for widgets
	def create_ui(self):
		#creating Vehicle type combo box widget
		self.combo_box_Vehtype = QComboBox(self)
		self.namelabel_Vehtype = QLabel(self)
		self.namelabel_Vehtype.setText('Select VehicleType:')
		self.namelabel_Vehtype.resize(200, 32)
		self.namelabel_Vehtype.move(10, 50)
		
		# setting Vehtype geometry of combo box
		self.combo_box_Vehtype.setGeometry(200, 55, 50, 50)

		# list of vehicles
		vehicle_list = ["Conti_Vehicles_CMC/BMW_5_FSF500", "BMW_5_BMWBrake ", "Vehicle3", "Vehicle4"]

		# making it editable
		self.combo_box_Vehtype.setEditable(True)
		
		# adding list of items to combo box
		self.combo_box_Vehtype.addItems(vehicle_list)
        
		# adjusting the size according to the maximum sized element
		self.combo_box_Vehtype.adjustSize()
		
		#bush button for select SD file
		self.pushbutton_inputfile = QPushButton('Select', self)
		self.pushbutton_inputfile.resize(25,120)
		self.pushbutton_inputfile.move(425, 153) 
		self.pushbutton_inputfile.adjustSize()
		
		#bush button for select SD file text alignment
		self.namelabel_inputfile = QLabel(self)
		self.namelabel_inputfile.setText('Scenario Description Input File:')
		self.line_inputfile = QLineEdit(self)
		self.line_inputfile.move(200, 150)
		self.line_inputfile.resize(200, 32)
		self.namelabel_inputfile.move(10, 150)
		self.namelabel_inputfile.adjustSize()
			
		#push button for selection of output folder
		self.pushbutton_outfolder = QPushButton('Select', self)
		self.pushbutton_outfolder.resize(50,35)
		self.pushbutton_outfolder.move(425, 250) 
		self.pushbutton_outfolder.adjustSize()
		
		#push button_output folder text alignment
		self.namelabel_outfolder = QLabel(self)
		self.namelabel_outfolder.setText('Output Folder:')
		self.line_outfolder = QLineEdit(self)
		self.line_outfolder.move(200, 250)
		self.line_outfolder.resize(200, 32)
		self.namelabel_outfolder.move(10, 250)
		self.namelabel_outfolder.adjustSize()
		
		#push button for generate button
		self.pushbutton_generate = QPushButton('Generate' ,self)
		self.pushbutton_generate.resize(50,50)
		self.pushbutton_generate.move(225, 350) 
		self.pushbutton_generate.adjustSize()

